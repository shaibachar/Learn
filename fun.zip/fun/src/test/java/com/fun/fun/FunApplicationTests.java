package com.fun.fun;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FunApplicationTests {

	@Test
	void contextLoads() {
	}

}
