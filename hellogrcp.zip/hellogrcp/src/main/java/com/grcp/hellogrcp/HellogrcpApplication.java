package com.grcp.hellogrcp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HellogrcpApplication {

	public static void main(String[] args) {
		SpringApplication.run(HellogrcpApplication.class, args);
	}

}
