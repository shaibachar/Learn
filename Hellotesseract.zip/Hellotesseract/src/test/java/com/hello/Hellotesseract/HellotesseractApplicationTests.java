package com.hello.Hellotesseract;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HellotesseractApplicationTests {

	@Test
	void contextLoads() {
	}

}
