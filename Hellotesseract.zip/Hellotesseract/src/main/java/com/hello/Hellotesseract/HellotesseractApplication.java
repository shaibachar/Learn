package com.hello.Hellotesseract;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HellotesseractApplication {

	public static void main(String[] args) {
		SpringApplication.run(HellotesseractApplication.class, args);
	}

}
